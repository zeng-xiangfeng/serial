//serial_demo.cpp
// #include <windows.h>

//sudo chmod 666 /dev/tty  打开串口
// 若上面sudo chmod 666 /dev/tty 不行，则sudo su 进入root模式

#include "std_msgs/Float32.h" //普通文本类型的消息
#include <sstream>
#include <ros/ros.h>
#include <serial/serial.h>
#include <iostream>
#include <string>
#include <deque>
#include <termio.h>
#include <iostream>
#include <iomanip> // 用于std::hex和std::setw
#include "serial_demo/Gas.h"



std::deque<float> stiff;
int stiffness = 0;
float stiffmin = 0;     //最低刚度
float stiffmax = 100;     //最大刚度
float stiffness_norm;   //归一化刚度



//把字符串换成对应的数字，比如A～F就是10～15
int hexCharToInt(char hexChar) {
    if (hexChar >= '0' && hexChar <= '9') {
        return hexChar - '0'; // 转换 '0'-'9'
    } else if (hexChar >= 'A' && hexChar <= 'F') {
        return 10 + hexChar - 'A'; // 转换 'A'-'F'
    } else if (hexChar >= 'a' && hexChar <= 'f') {
        return 10 + hexChar - 'a'; // 转换 'a'-'f'
    } else {
        return -1; // 非法字符
    }
}

int get_char()
{
    fd_set rfds;
    struct timeval tv;
    int ch = 0;
    FD_ZERO(&rfds);
    FD_SET(0, &rfds);
    tv.tv_sec = 0;
    tv.tv_usec = 10; //设置等待超时时间
    if (select(1, &rfds, NULL, NULL, &tv) > 0) //检测键盘是否有输入
    {
        ch = getchar(); 
        
    }
    return ch;
}


// int scanKeyboard()
// {
//     int input;
//     struct termios new_settings;
//     struct termios stored_settings;
//     tcgetattr(0,&stored_settings);
//     new_settings = stored_settings;
//     new_settings.c_lflag &= (~ICANON);
//     new_settings.c_cc[VTIME] = 0;
//     tcgetattr(0,&stored_settings);
//     new_settings.c_cc[VMIN] = 1;
//     tcsetattr(0,TCSANOW,&new_settings);
      
//     input = getchar();
      
//     tcsetattr(0,TCSANOW,&stored_settings);
//     return input;
// }


int main(int argc, char** argv)
{
    setlocale(LC_ALL,"");
    ros::init(argc, argv, "serial_port");
    ros::NodeHandle n;
    ros::Publisher pub = n.advertise<serial_demo::Gas>("gas_serial",10);
    std_msgs::Float32 msg;

    double CO,H2S,O2,CH4;
    int high_low[4];
    //创建一个serial对象
    serial::Serial sp;
    //创建timeout
    serial::Timeout to = serial::Timeout::simpleTimeout(100);
    //设置要打开的串口名称
    sp.setPort("/dev/ttyACM0");
    //设置串口通信的波特率
    sp.setBaudrate(9600);
    //串口设置timeout
    sp.setTimeout(to);
 
    try
    {
        //打开串口
        sp.open();
    }
    catch(serial::IOException& e)
    {
        ROS_ERROR_STREAM("Unable to open port.");
        return -1;
    }
    
    //判断串口是否打开成功
    if(sp.isOpen())
    {
        ROS_INFO_STREAM("/dev/ttyUSB0 is opened.");
    }
    else
    {
        return -1;
    }
    
    // char hex_buffer[1023]; // 用于存储十六进制字符串的缓冲区
    // uint8_t hex_buffer[511]; 
    // hex_buffer[0] = '\0';

    ros::Rate loop_rate(60);
    while(ros::ok())
    {
        // int Stiff_temp = 0;
        // int Stiff_temp_max = 0;
    //    ros::Duration(5.0).sleep();
        //获取缓冲区内的字节数
        size_t n = sp.available();
        // std::cout<<"******n="<<n<<std::endl;

        stiffness_norm;
        char hex_buffer[1023] = {};   //每次循环把hex_buffer清空
        if(n!=0)
        {
            uint8_t buffer[511];
            n = sp.read(buffer, n);
            // std::cout<<"******buffer="<<buffer<<std::endl;
            std::string hexString;
            for (size_t i = 0; i < n; ++i) {
                
               sprintf(hex_buffer + strlen(hex_buffer), "%02X ", (unsigned char)buffer[i]);
            }
            
            std::cout<<"******hex_buffer="<<hex_buffer<<std::endl;
            // std::cout<<"******n="<<n<<std::endl;

            for (int i = 0; i < 100; i++)
            {
                int value1 = hexCharToInt(hex_buffer[i]);
                int value2 = hexCharToInt(hex_buffer[i+1]);

                int value3 = hexCharToInt(hex_buffer[i+6]);
                int value4 = hexCharToInt(hex_buffer[i+7]);

                int value5 = hexCharToInt(hex_buffer[i+9]);
                int value6 = hexCharToInt(hex_buffer[i+10]);

                int value7 = hexCharToInt(hex_buffer[i+12]);
                int value8 = hexCharToInt(hex_buffer[i+13]);

                int value9 = hexCharToInt(hex_buffer[i+15]);
                int value10 = hexCharToInt(hex_buffer[i+16]);

                int value11 = hexCharToInt(hex_buffer[i+18]);
                int value12 = hexCharToInt(hex_buffer[i+19]);

                int value13 = hexCharToInt(hex_buffer[i+21]);
                int value14 = hexCharToInt(hex_buffer[i+22]);


                int value15 = hexCharToInt(hex_buffer[i+24]);
                int value16 = hexCharToInt(hex_buffer[i+25]);


                int value17 = hexCharToInt(hex_buffer[i+27]);
                int value18 = hexCharToInt(hex_buffer[i+28]);


                int value19 = hexCharToInt(hex_buffer[i+30]);
                int value20 = hexCharToInt(hex_buffer[i+31]);


                 int hexValue1 = (value1 << 4) + value2;

                //8个数据位，每个数据位由2个十六进制的组成
                 int hexValue2 = (value3 << 4) + value4;
                 int hexValue3 = (value5 << 4) + value6;
                 int hexValue4 = (value7 << 4) + value8;
                 int hexValue5 = (value9 << 4) + value10;
                 int hexValue6 = (value11 << 4) + value12;
                 int hexValue7 = (value13 << 4) + value14;
                 int hexValue8 = (value15 << 4) + value16;
                 int hexValue9 = (value17 << 4) + value18;

                 int hexValue10 = (value19 << 4) + value20;

                //最终4种气体由2个数据位组成，就是0x00与0xD1高低位合成
                
                high_low[0]= (hexValue2<<8)+hexValue3;
                high_low[1]= (hexValue4<<8)+hexValue5;
                high_low[2]= (hexValue6<<8)+hexValue7;
                high_low[3]= (hexValue8<<8)+hexValue9;  


                if (hexValue1==255&hexValue10==169)
                {

                    CO=high_low[0]*1;
                    H2S=high_low[1]*1;
                    O2=high_low[2]*0.1;
                    CH4=high_low[3]*1;
                    std::cout<<"CO="<<CO<<std::endl;
                    std::cout<<"H2S="<<H2S<<std::endl;
                    std::cout<<"O2="<<O2<<std::endl;
                    std::cout<<"CH4="<<CH4<<std::endl;

                    break;
                }
                else
                {
                    std::cout<<"********在寻找中********"<<std::endl;
                }
                
                
            }
            
        


        //     for (int i = 0; i < n; i++)
        //         {
        //             char ch = buffer[i];
        //             if(ch >= 48 && ch <= 57)    //正常数值
        //             {
        //                 Stiff_temp = (Stiff_temp*10 + (ch - 48));
        //             }
        //             else if((ch == 10 || ch == 44)) //   换行/n 或者逗号,  则完成一个数值的提取
        //             {
        //                 if((Stiff_temp > Stiff_temp_max) && Stiff_temp <= 1000)
        //                 {
        //                     Stiff_temp_max = Stiff_temp;
        //                 }
        //                 Stiff_temp = 0;
        //             }

        //         }

        //     if(stiff.size() > 50)    //超过xx个则去掉头部一个
        //     {
        //         stiff.pop_front();
        //     }

        //     stiff.push_back(Stiff_temp_max);    //尾部加入新值

        //    float stiff_mean = 0;
        //     for(float i = 0; i<stiff.size() ; i++)
        //     {
        //         stiff_mean += stiff[i]/(stiff.size()+1);
                
        //     }
            
        // //    stiffness = round(stiffness/(stiff.size()+1) + stiff_mean);
        //     int stiffness_t = round(stiffness/(stiff.size()+1) + stiff_mean);

           
        //     if(abs((float)(stiffness_t - stiffness)/stiffness) > 0.000001)
        //     {
        //         stiffness = stiffness_t;
        //     }

        //     int ch = get_char();
        //     // int ch = scanKeyboard();

        //     if( ch == 97 )
        //     {
        //         //设置最大值
        //         stiffmax = stiffness;
        //          FILE* fpp=fopen("data.txt","w+");
        //         fclose(fpp);
        //         //std::cout<<" a = "<<ch<<std::endl;
        //     }
        //     if( ch == 98 )
        //     {
        //         //设置最小值
        //         stiffmin = stiffness;
        //         //std::cout<<" b = "<<ch<<std::endl;
        //     }

        //     std::cout<<"min: "<<stiffmin<<std::endl;
        //     std::cout<<"max: "<<stiffmax<<std::endl;

        //     stiffness_norm = (stiffness - stiffmin)/(stiffmax - stiffmin);
           
        //     if(stiffness_norm <= 0)
        //     {
        //         stiffness_norm = 0;
        //     }
        //     else if(stiffness_norm >= 1)
        //     {
        //         stiffness_norm = 1;
        //     }
        //     stiffness_norm = stiffness_norm*100;
            serial_demo::Gas g;
            g.gas[0]=CO;
            g.gas[1]=H2S;
            g.gas[2]=O2;
            g.gas[3]=CH4;
            
            pub.publish(g);


            FILE* fp=fopen("data.txt","a+");
            fprintf(fp,"%f\n",stiffness_norm);
            fclose(fp);
             
            // std::cout << std::endl;
            //把数据发送回去
            sp.write(buffer, n);
        }
        loop_rate.sleep();
        ros::spinOnce();
    }
    
    //关闭串口
    sp.close();
 
    return 0;
}