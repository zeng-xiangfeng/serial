//sudo chmod 666 /dev/tty  先打开串口权限
// 若上面sudo chmod 666 /dev/tty 不行，则sudo su 进入root模式
// Gas.msg文件中用float32编译可以通过，但是用double却不行
// 当文件中有build和devel时，需要source ./devel/set.bash才能编译